package com.example.codexuser

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
