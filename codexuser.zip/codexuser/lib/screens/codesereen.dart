import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';
import 'package:flutter_highlighter/flutter_highlighter.dart';

class CodesScreen extends StatefulWidget {
  final String? courseId;
  final String? topicId;
  final String? topicName;

  const CodesScreen({
    Key? key,
    required this.courseId,
    required this.topicId,
    required this.topicName,
  }) : super(key: key);

  @override
  State<CodesScreen> createState() => _CodesScreenState();
}

class _CodesScreenState extends State<CodesScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("${widget.topicName}"),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Color.fromARGB(255, 104, 177, 237),
              Color.fromARGB(255, 127, 6, 149),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 60, bottom: 60, left: 20, right: 20),
              child: Row(
                children: [
                  Container(
                    height: 100,
                    width: 100,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(100)),
                      image: DecorationImage(
                        image: NetworkImage(
                          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR4AYgPHxqTfSqoTamM5Gnt2KH4VNyQQzc6ipa6PUHobn56cSLLR8h_tgdZpCTJO6nou5E&usqp=CAU"
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Column(
                      children: [
                        Text(
                          "${widget.topicName}",
                          style: TextStyle(fontSize: 20, fontWeight: FontWeight.w400),
                        ),
                        Text(
                          "In ${widget.topicName}",
                          style: TextStyle(fontSize: 20, fontWeight: FontWeight.w400),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(40),
                    topRight: Radius.circular(40),
                  ),
                ),
                child: StreamBuilder<QuerySnapshot>(
                  stream: FirebaseFirestore.instance
                      .collection("Courses")
                      .doc(widget.courseId)
                      .collection("Topics")
                      .doc(widget.topicId)
                      .collection("Codes")
                      .snapshots(),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const Center(child: CircularProgressIndicator());
                    }

                    if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                      return Center(child: Text("No data available"));
                    }

                    final codes = snapshot.data!.docs;

                    return ListView.builder(
                      itemCount: codes.length,
                      itemBuilder: (context, index) {
                        var codeDoc = codes[index].data() as Map<String, dynamic>?;

                        if (codeDoc == null) {
                          return ListTile(
                            title: Text("Invalid code entry"),
                            subtitle: Text("This code entry is missing required data."),
                          );
                        }

                        String code = codeDoc['code'] ?? 'No code available';
                        String description = codeDoc['description'] ?? 'No description available';

                        String? youtubeLink = codeDoc['description'];

                        return Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Center(
                            child: Padding(
                              padding: const EdgeInsets.only(right: 20, left: 20, top: 29),
                              child: InkWell(
                                onTap: () {
                                  if (youtubeLink != null && youtubeLink.isNotEmpty) {
                                    String videoId = _extractVideoId(youtubeLink);
                                    if (videoId.isNotEmpty) {
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (context) => YouTubePlayerScreen(videoId: videoId),
                                        ),
                                      );
                                    } else {
                                      ScaffoldMessenger.of(context).showSnackBar(
                                        SnackBar(content: Text("Invalid YouTube link provided.")),
                                      );
                                    }
                                  } else {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(content: Text("YouTube link not available.")),
                                    );
                                  }
                                },
                                child: Expanded(
                                  child: Container(
                                    
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.all(Radius.circular(30)),
                                      color: Color.fromARGB(255, 218, 214, 214),
                                      border: Border.all(width: 2, color: Colors.grey),
                                      boxShadow: [
                                        BoxShadow(
                                          spreadRadius: 5,
                                          offset: Offset(5, 5),
                                          blurRadius: 20,
                                          blurStyle: BlurStyle.normal,
                                          color: Colors.grey,
                                        ),
                                      ],
                                    ),
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Padding(
                                          padding: const EdgeInsets.all(10),
                                          child: HighlightView(
                                            
                                            code,
                                            language: 'dart', // Set to 'dart' or appropriate language
                                            textStyle: TextStyle(fontWeight: FontWeight.bold,backgroundColor: Colors.black,color: Colors.white),
                                          ),
                                        ),
                                        SizedBox(height: 8.0),
                                        Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: Text(description),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _extractVideoId(String? youtubeLink) {
    if (youtubeLink == null) return '';
    RegExp regExp = RegExp(r"(?:v=|\/|embed\/|youtu.be\/|\/v\/|\/e\/|watch\?v=|watch\?.+&v=)([^#&?]*)(?=\s|$)");
    Match? match = regExp.firstMatch(youtubeLink);
    return match != null ? match.group(1) ?? '' : '';
  }
}

class YouTubePlayerScreen extends StatefulWidget {
  final String videoId;

  const YouTubePlayerScreen({Key? key, required this.videoId}) : super(key: key);

  @override
  _YouTubePlayerScreenState createState() => _YouTubePlayerScreenState();
}

class _YouTubePlayerScreenState extends State<YouTubePlayerScreen> {
  late YoutubePlayerController _controller;

  @override
  void initState() {
    super.initState();
    _controller = YoutubePlayerController(
      initialVideoId: widget.videoId,
      flags: YoutubePlayerFlags(
        autoPlay: true,
        mute: false,
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('YouTube Player')),
      body: Center(
        child: YoutubePlayerBuilder(
          player: YoutubePlayer(
            controller: _controller,
            showVideoProgressIndicator: true,
          ),
          builder: (context, player) {
            return Column(
              children: [
                player,
                SizedBox(height: 20),
                Text(
                  'Now Playing',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
