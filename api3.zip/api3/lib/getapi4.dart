import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
// import 'package:flutter_cors/flutter_cors.dart'; // Uncomment if needed and added to pubspec.yaml

class Getapi4 extends StatefulWidget {
  const Getapi4({super.key});

  @override
  State<Getapi4> createState() => _Getapi4State();
}

class _Getapi4State extends State<Getapi4> {
  Map<String, dynamic> data = {};
  bool loading = true;

  Future<void> fetchData() async {
    var url = Uri.parse("https://api.api-ninjas.com/v1/weather?city=London");
    // var headers = <String, String>{
    //   'x-api-key': 'D7YpVRLAQp44HQFtxYXFNg==EHlxn9Srm1yy2sSn',
    //   'Content-Type': 'application/json',
    // };

    // var response = await http.get(url, headers: headers);
 var response = await http.get(url);
    debugPrint("Status Code: ${response.statusCode}");
    if (response.statusCode == 200) {
      setState(() {
        loading = false;
        data = jsonDecode(response.body);
      });
    } else {
      debugPrint("Failed to fetch data: ${response.reasonPhrase}");
    }
  }

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  @override
  Widget build(BuildContext context) {
    debugPrint("Data: $data");

    return Scaffold(
      appBar: AppBar(title: const Text("Weather Data")),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : Center(
              child: Container(
                padding: const EdgeInsets.all(20),
                color: const Color.fromARGB(255, 142, 138, 143),
                child: Text(
                  data.isNotEmpty ? data.toString() : "No data available",
                  style: const TextStyle(color: Colors.white),
                ),
              ),
            ),
    );
  }
}
