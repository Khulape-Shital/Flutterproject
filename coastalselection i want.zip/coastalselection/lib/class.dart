class Beach {
  final String name;
  final String waveHeight;
  final String waterQuality;
  final String windSpeed;
  final String tideLevel;

  Beach({
    required this.name,
    required this.waveHeight,
    required this.waterQuality,
    required this.windSpeed,
    required this.tideLevel,
  });
}

class StateBeaches {
  final String stateName;
  final List<Beach> beaches;

  StateBeaches({required this.stateName, required this.beaches});
}
