import 'package:coastalselection/BeachSelectionScreen.dart';
import 'package:coastalselection/class.dart';
import 'package:flutter/material.dart';

// Example data
List<StateBeaches> stateBeachesData = [
  StateBeaches(stateName: 'Kerala Beaches', beaches: [
    Beach(name: 'Varkala Beach', waveHeight: '1–3 meters', waterQuality: 'Good to Excellent', windSpeed: '15–30 km/h', tideLevel: 'High tide: 1.5 meters'),
    Beach(name: 'Kovalam Beach', waveHeight: '1–2 meters', waterQuality: 'Good', windSpeed: '10–20 km/h', tideLevel: 'High tide: 1.4 meters'),
  ]),
  StateBeaches(stateName: 'Goa Beaches', beaches: [
    Beach(name: 'Baga Beach', waveHeight: '0.5–1.5 meters', waterQuality: 'Good', windSpeed: '12–20 km/h', tideLevel: 'High tide: 1.2 meters'),
    Beach(name: 'Calangute Beach', waveHeight: '1–2 meters', waterQuality: 'Good', windSpeed: '12–20 km/h', tideLevel: 'High tide: 1.3 meters'),
  ]),
];

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Home')),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            // Navigate to BeachSelectionScreen with data
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => BeachSelectionScreen(stateBeachesData: stateBeachesData),
              ),
            );
          },
          child: Text('Select a Beach'),
        ),
      ),
    );
  }
}
