package com.example.coastalselection

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
