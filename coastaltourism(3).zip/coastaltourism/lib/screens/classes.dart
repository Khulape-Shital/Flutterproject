class category{

  String? types;

  category(this.types);

}

class images{

  String? beachImages;

 images(this.beachImages);

} 
class Images {
  final String imageUrl;

  Images(this.imageUrl);
}

class Info{
    final String watertemp;
    Info(this.watertemp);

}

void fun(List topic){


  }