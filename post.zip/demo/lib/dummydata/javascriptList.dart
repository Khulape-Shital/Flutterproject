List javascriptTopics = [
  {
    "topicName" : "introduction to javascript",
    "topicCodes": ["one","two","three"]
  },
   {
    "topicName" : "Operators JS",
    "topicCodes": ["operator code 1","operator code 2","operator code 3"]
  },
   {
    "topicName" : "Data type JS",
    "topicCodes": ["operator code 1","operator code 2","operator code 3"]
  },
   {
    "topicName" : "Data type JS",
    "topicCodes": ["operator code 1","operator code 2","operator code 3"]
  },
   {
    "topicName" : "Data type JS",
    "topicCodes": ["operator code 1","operator code 2","operator code 3"]
  },
];