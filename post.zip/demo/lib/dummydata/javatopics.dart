List javaTopics = [
  {
    "topicName" : "introduction to java",
    "topicCodes": ["one","two","three"]
  },
   {
    "topicName" : "Operators",
    "topicCodes": ["operator code 1","operator code 2","operator code 3"]
  },
   {
    "topicName" : "Data type",
    "topicCodes": ["data type code 1","operator code 2","operator code 3"]
  },
   {
    "topicName" : "Inherirance",
    "topicCodes": ["inher code 1","operator code 2","operator code 3"]
  },
   {
    "topicName" : "polymorph",
    "topicCodes": ["polymorph code 1","operator code 2","operator code 3"]
  },
];