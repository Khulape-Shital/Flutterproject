import 'package:flutter/material.dart';

class Screen3 extends StatelessWidget {
  Screen3({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        color: Colors.black,
        height: 200,
        width: 200,
      ),
    );
  }
}
