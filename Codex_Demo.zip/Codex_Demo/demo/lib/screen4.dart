import 'package:flutter/material.dart';

class Screen4 extends StatelessWidget {
  Screen4({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        color: Colors.black,
        height: 200,
        width: 200,
      ),
    );
  }
}
