List programming = [
  {
    "Languages": [
      "images/js.jpeg",
      "images/c.png",
      "images/c++.png",
      "images/java.jpeg",
      "images/python.png"
    ],
    "courses": [
      "images/data_Science.jpeg",
      "images/java_stack.jpg",
      "images/machine_learning.webp",
      "images/mern_stack.png"
    ],
   
    
  },
  {
    "Timing":["9 TO 11","11.30 TO 1.30","2 TO 4","4.30 TO6.30"],
    "course":["Data Science","Java Full Stack","MAchine Lerning","Mern Stack"],
    
    "Dates":["9 March 2024","14 Jan 2024","9 Nov 2024","2 Feb 2025"],
    "upcomming":[
      "images/data_Science.jpeg",
      "images/java_stack.jpg",
      "images/machine_learning.webp",
      "images/mern_stack.png"
    ],
  },{
    "topicName": ["JavaScript","c","c++","java","Python"],
    "topics": [
      "variables",
      "Data Types",
      "Opperators",
      "Loops",
      "control Statement",
      "Opps",
    ],
   
    "langTopics": [
      ["X", "y", "A", "B"],
      ["Integer", "Float", "double", "char"],
      ["Arithmetic", "Logical", "Unary", "Bitwise", "Assignment", "Relational"],
      ["For Loop", "While Loop", "do While Loop"],
      ["IF-Else", "Switch"],
      [ "constructor","Inheritance","Abstraction","Overloading","Overriding","setters-getters"  ]
    ],

  },

{"variables":["X","y","A","B"],
    "DataTypes":["Integer","Float","double","char"],
    "OPerators":["Arithmatic","Logical","Unary","Bitwise","Assignment","Relational"],
    "Loops":["For Loop","While Loop","do While Loop"],
    "control statments":["IF-Else","Switch",],
    "Opps":["constructor","Inheritance","Abstraction","Overloadein","Overriding","setters-getters"]}
  
];