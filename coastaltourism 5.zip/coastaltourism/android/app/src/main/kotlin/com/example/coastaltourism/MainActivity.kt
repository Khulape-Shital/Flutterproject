package com.example.coastaltourism

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
