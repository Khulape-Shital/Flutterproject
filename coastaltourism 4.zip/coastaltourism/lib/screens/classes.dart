class category{

  String? types;

  category(this.types);

}

class images{

  String? beachImages;
  String? beachName;
  String? beachInfo;
  Map? details;

 images(this.beachImages,this.beachName, this.beachInfo,this.details);

} 


class Info{
    final String watertemp;
    Info(this.watertemp);

}

void fun(List topic){


  }
  